
import React, { useState, useEffect, useRef } from 'react';
import { User, Camel, VerificationStatus, Herd, HerdRole, UserRole, DocumentType, Gender, CamelDocument } from './types';
import { MOCK_USERS, MOCK_CAMELS } from './mockData';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Directory from './pages/Directory';
import CamelProfile from './pages/CamelProfile';
import Landing from './pages/Landing';
import Register from './pages/Register';
import Auth from './pages/Auth';
import HerdFamily from './pages/HerdFamily';
import { ICONS, BREEDS } from './constants';
import { syncCamelToCloud, syncHerdToCloud, fetchAllCamels } from './supabaseService';

const App: React.FC = () => {
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('herd_pro_users');
      return saved ? JSON.parse(saved) : MOCK_USERS;
    } catch (e) { return MOCK_USERS; }
  });
  
  const [herds, setHerds] = useState<Herd[]>(() => {
    try {
      const saved = localStorage.getItem('herd_pro_herds');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [{
      id: 'h1',
      name: 'Al-Saud Royal Herd',
      ownerId: 'u1',
      inviteCode: 'SAUD77',
      members: [
        { userId: 'u1', name: 'Ahmed Al-Saud', email: 'owner@example.com', role: HerdRole.OWNER },
        { userId: 'u2', name: 'Mustafa Admin', email: 'mustafa@herd.com', role: HerdRole.MANAGER }
      ]
    }];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('herd_pro_session');
      return saved ? JSON.parse(saved) : null;
    } catch (e) { return null; }
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [camels, setCamels] = useState<Camel[]>(() => {
    try {
      const saved = localStorage.getItem('herd_pro_camels');
      return saved ? JSON.parse(saved) : MOCK_CAMELS;
    } catch (e) { return MOCK_CAMELS; }
  });
  
  const [selectedCamel, setSelectedCamel] = useState<Camel | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(!!currentUser);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isAddCamelOpen, setIsAddCamelOpen] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [certPreview, setCertPreview] = useState<{name: string, data: string} | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const certInputRef = useRef<HTMLInputElement>(null);
  const [currentHerd, setCurrentHerd] = useState<Herd | null>(null);

  // Cloud Sync Status
  const [isSyncing, setIsSyncing] = useState(false);

  // Parent Lookup States
  const [sireChipQuery, setSireChipQuery] = useState('');
  const [damChipQuery, setDamChipQuery] = useState('');
  const [foundSire, setFoundSire] = useState<Camel | null>(null);
  const [foundDam, setFoundDam] = useState<Camel | null>(null);
  const [sireError, setSireError] = useState<string | null>(null);
  const [damError, setDamError] = useState<string | null>(null);

  const [includeVerification, setIncludeVerification] = useState(false);

  // Fix: Derived isAdmin from currentUser to be available in component scope and JSX
  const isAdmin = currentUser?.role === UserRole.ADMIN;

  // Initial Cloud Fetch
  useEffect(() => {
    const initCloudData = async () => {
      setIsSyncing(true);
      const cloudCamels = await fetchAllCamels();
      if (cloudCamels && cloudCamels.length > 0) {
        setCamels(cloudCamels);
      }
      setIsSyncing(false);
    };
    initCloudData();
  }, []);

  // Save to LocalStorage and Sync to Supabase
  useEffect(() => {
    try {
      localStorage.setItem('herd_pro_camels', JSON.stringify(camels));
      // In a real app, you'd only sync the changed item, but for this demo:
      camels.forEach(camel => syncCamelToCloud(camel));
    } catch (e) {
      console.warn("Storage quota full.");
    }
  }, [camels]);

  useEffect(() => {
    localStorage.setItem('herd_pro_users', JSON.stringify(users));
    localStorage.setItem('herd_pro_herds', JSON.stringify(herds));
    herds.forEach(herd => syncHerdToCloud(herd));
  }, [users, herds]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('herd_pro_session', JSON.stringify(currentUser));
      const userHerd = herds.find(h => h.id === currentUser.herdId);
      setCurrentHerd(userHerd || null);
    } else {
      localStorage.removeItem('herd_pro_session');
      setCurrentHerd(null);
    }
  }, [currentUser, herds]);

  // Parent lookup with gender validation
  useEffect(() => {
    if (sireChipQuery) {
      const found = camels.find(c => c.chipNumber.toLowerCase().trim() === sireChipQuery.toLowerCase().trim());
      if (found) {
        if (found.gender !== Gender.MALE) {
          setFoundSire(null);
          setSireError(`${found.name} is ${found.gender}. Father must be MALE.`);
        } else {
          setFoundSire(found);
          setSireError(null);
        }
      } else {
        setFoundSire(null);
        setSireError(null);
      }
    } else {
      setFoundSire(null);
      setSireError(null);
    }
  }, [sireChipQuery, camels]);

  useEffect(() => {
    if (damChipQuery) {
      const found = camels.find(c => c.chipNumber.toLowerCase().trim() === damChipQuery.toLowerCase().trim());
      if (found) {
        if (found.gender !== Gender.FEMALE) {
          setFoundDam(null);
          setDamError(`${found.name} is ${found.gender}. Mother must be FEMALE.`);
        } else {
          setFoundDam(found);
          setDamError(null);
        }
      } else {
        setFoundDam(null);
        setDamError(null);
      }
    } else {
      setFoundDam(null);
      setDamError(null);
    }
  }, [damChipQuery, camels]);

  const handleLoginClick = () => { setIsLoggingIn(true); setIsRegistering(false); };
  const handleRegisterClick = () => { setIsRegistering(true); setIsLoggingIn(false); };

  const handleAuthSubmit = async (email: string, pass: string): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 800));
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === pass);
    if (user) {
      setCurrentUser(user);
      setIsLoggedIn(true);
      setIsLoggingIn(false);
      setIsRegistering(false);
      if (user.role === UserRole.ADMIN) setActiveTab('admin');
      else if (!user.herdId) setActiveTab('family');
      else setActiveTab('dashboard');
      return true;
    }
    return false;
  };

  const handleRegister = async (data: { name: string; email: string; pass: string }): Promise<{ success: boolean; message?: string }> => {
    const emailExists = users.some(u => u.email.toLowerCase() === data.email.toLowerCase());
    if (emailExists) return { success: false, message: "Email already taken." };
    const newUser: User = { id: `u${Date.now()}`, name: data.name, email: data.email, password: data.pass, role: UserRole.USER, createdAt: new Date().toISOString() };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    setIsLoggedIn(true);
    setIsRegistering(false);
    setIsLoggingIn(false);
    setActiveTab('family'); 
    return { success: true };
  };

  const handleLogout = () => { setCurrentUser(null); setIsLoggedIn(false); setSelectedCamel(null); setActiveTab('dashboard'); };

  const handleUpdateCamel = (updatedCamel: Camel) => {
    setCamels(prev => prev.map(c => c.id === updatedCamel.id ? updatedCamel : c));
    setSelectedCamel(updatedCamel);
  };

  const handleJoinHerd = (code: string) => {
    const targetHerd = herds.find(h => h.inviteCode === code.toUpperCase());
    if (targetHerd && currentUser) {
      const isMember = targetHerd.members.some(m => m.userId === currentUser.id);
      if (!isMember) {
        const updatedHerd = { ...targetHerd, members: [...targetHerd.members, { userId: currentUser.id, name: currentUser.name, email: currentUser.email, role: HerdRole.OWNER }] };
        setHerds(prev => prev.map(h => h.id === targetHerd.id ? updatedHerd : h));
      }
      const updatedUser = { ...currentUser, herdId: targetHerd.id, herdRole: HerdRole.MANAGER };
      setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedUser : updatedUser));
      setCurrentUser(updatedUser);
      setActiveTab('dashboard');
    } else {
      alert("Invalid code.");
    }
  };

  const handleCreateHerd = (name: string) => {
    if (!currentUser) return;
    const newHerdId = `h${Date.now()}`;
    const newHerd: Herd = { 
      id: newHerdId, 
      name: name || 'My Family Herd', 
      ownerId: currentUser.id, 
      inviteCode: Math.random().toString(36).substring(2, 8).toUpperCase(), 
      members: [{ userId: currentUser.id, name: currentUser.name, email: currentUser.email, role: HerdRole.OWNER }] 
    };
    const updatedUser = { ...currentUser, herdId: newHerdId, herdRole: HerdRole.OWNER };
    setHerds(prev => [...prev, newHerd]);
    setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedUser : u));
    setCurrentUser(updatedUser);
    setActiveTab('dashboard');
  };

  const handleAddCamelSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormError(null);
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    const chipNumber = data.chipNumber as string;
    
    if (camels.some(c => c.chipNumber === chipNumber)) {
      setFormError(`Chip ID "${chipNumber}" already registered.`);
      return;
    }

    if (sireError || damError) {
      setFormError("Heritage data contains biological errors. Please review parent chip IDs.");
      return;
    }

    const initialStatus = includeVerification ? VerificationStatus.PENDING : VerificationStatus.NOT_REQUESTED;
    // Fix: isAdmin is now available from component scope
    const finalStatus = (isAdmin && data.isVerified === 'on') ? VerificationStatus.VERIFIED : initialStatus;

    const camelId = `c${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const docs: CamelDocument[] = [];
    
    if (certPreview) {
      docs.push({
        id: `d${Date.now()}`,
        camelId: camelId,
        type: DocumentType.DNA_TEST,
        fileName: certPreview.name,
        fileUrl: certPreview.data, // Stores Base64 string for persistent cloud storage
        fileSize: Math.round(certPreview.data.length * 0.75),
        uploadedBy: currentUser!.id,
        status: finalStatus,
        uploadDate: new Date().toISOString()
      });
    }

    const newCamel: Camel = {
      id: camelId,
      registrationNumber: chipNumber,
      chipNumber: chipNumber,
      herdId: currentUser!.herdId || 'temp_herd',
      ownerId: currentUser!.id,
      ownerName: currentUser!.name,
      name: data.name as string || 'Unnamed',
      gender: data.gender as Gender,
      dateOfBirth: data.dateOfBirth as string,
      breed: data.breed as string,
      imageUrl: imagePreview || undefined,
      markings: 'None',
      physicalDescription: 'Registry Record',
      healthStatus: 'Healthy',
      verificationStatus: finalStatus,
      verifiedBy: includeVerification ? (data.verifiedBy as string) : undefined,
      dnaFacility: includeVerification ? (data.dnaFacility as string) : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      adminData: [],
      documents: docs,
      sireId: foundSire?.id,
      damId: foundDam?.id,
      manualSireName: !foundSire ? data.manualSireName as string : undefined,
      manualDamName: !foundDam ? data.manualDamName as string : undefined,
    };

    setCamels(prev => [newCamel, ...prev]);
    setIsAddCamelOpen(false);
    setImagePreview(null);
    setCertPreview(null);
    setIncludeVerification(false);
    setSireChipQuery('');
    setDamChipQuery('');
  };

  const handleStatusQuickChange = (camelId: string, status: VerificationStatus) => {
    if (currentUser?.role !== UserRole.ADMIN) {
      alert("Only registry administrators can perform this action.");
      return;
    }
    setCamels(prev => prev.map(c => c.id === camelId ? { ...c, verificationStatus: status, updatedAt: new Date().toISOString() } : c));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 800000) { 
        alert("Image too large. Max 800KB for registry storage.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCertChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1000000) {
        alert("Certificate file too large. Max 1MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => setCertPreview({ name: file.name, data: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  return (
    <Layout user={currentUser} onLogout={handleLogout} activeTab={activeTab} setActiveTab={(t) => { setActiveTab(t); setSelectedCamel(null); }} onLogoClick={() => { setSelectedCamel(null); setActiveTab('dashboard'); }}>
      {isSyncing && (
        <div className="fixed top-20 right-8 z-[200] flex items-center gap-2 bg-white px-4 py-2 rounded-full border border-gray-100 shadow-xl animate-bounce">
           <div className="w-2 h-2 bg-[#D2691E] rounded-full"></div>
           <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Supabase Sync Active</span>
        </div>
      )}

      {!isLoggedIn ? (
        isRegistering ? <Register onRegister={handleRegister} onBack={() => { setIsRegistering(false); setIsLoggingIn(true); }} /> :
        isLoggingIn ? <Auth onLogin={handleAuthSubmit} onRegister={handleRegisterClick} onBack={() => setIsLoggingIn(false)} /> :
        <Landing onLogin={handleLoginClick} onRegister={handleRegisterClick} onChipLookup={(chip) => { const f = camels.find(c => c.chipNumber === chip); if (f) setSelectedCamel(f); else alert("Not found."); }} />
      ) : selectedCamel ? (
        <CamelProfile camel={selectedCamel} user={currentUser} onUpdate={handleUpdateCamel} onBack={() => setSelectedCamel(null)} camels={camels} onViewCamel={setSelectedCamel} />
      ) : (
        <>
          {activeTab === 'dashboard' && <Dashboard user={currentUser!} camels={camels.filter(c => c.herdId === currentUser?.herdId)} onAddCamel={() => { setFormError(null); setIncludeVerification(false); setIsAddCamelOpen(true); }} onViewCamel={setSelectedCamel} onNavigateToFamily={() => setActiveTab('family')} onChipLookup={(chip) => { const f = camels.find(c => c.chipNumber === chip); if (f) setSelectedCamel(f); else alert("Not found."); }} />}
          {activeTab === 'directory' && <Directory camels={camels.filter(c => c.herdId === currentUser?.herdId)} onViewCamel={setSelectedCamel} onNavigateToFamily={() => setActiveTab('family')} />}
          {activeTab === 'family' && <HerdFamily user={currentUser!} herd={currentHerd} onJoinHerd={handleJoinHerd} onCreateHerd={handleCreateHerd} />}
          {activeTab === 'admin' && currentUser?.role === UserRole.ADMIN && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <h2 className="text-3xl font-black text-[#3E2723]">Admin Registry Review</h2>
              <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden divide-y divide-gray-50">
                {camels.filter(c => c.verificationStatus === VerificationStatus.PENDING).map(c => (
                   <div key={c.id} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-4">
                         <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-[#D2691E]">
                            {c.imageUrl ? <img src={c.imageUrl} className="w-full h-full object-cover" /> : <ICONS.Camel className="w-6 h-6" />}
                         </div>
                         <div>
                            <p className="font-black text-[#3E2723]">{c.name}</p>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{c.breed} • Owner: {c.ownerName}</p>
                         </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => setSelectedCamel(c)} className="px-4 py-2 text-[10px] font-black uppercase text-gray-500 hover:text-[#3E2723]">Details</button>
                        <button onClick={() => handleStatusQuickChange(c.id, VerificationStatus.VERIFIED)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-600/20">Verify</button>
                      </div>
                   </div>
                ))}
              </div>
            </div>
          )}
          {activeTab === 'profile' && (
            <div className="max-w-md mx-auto bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-xl text-center">
              <div className="w-20 h-20 bg-[#3E2723] rounded-full mx-auto flex items-center justify-center text-white text-3xl font-black mb-6">{currentUser?.name.charAt(0)}</div>
              <h3 className="text-2xl font-black text-[#3E2723]">{currentUser?.name}</h3>
              <p className="text-gray-400 font-medium">{currentUser?.email}</p>
              <div className="mt-10 pt-6 border-t border-gray-50 flex flex-col gap-4">
                 <button onClick={handleLogout} className="text-sm font-black text-red-500 hover:text-red-700">Sign Out Registry</button>
                 <button onClick={() => { localStorage.clear(); window.location.reload(); }} className="text-[10px] font-black text-gray-300 uppercase tracking-widest">Wipe Local Storage</button>
              </div>
            </div>
          )}
        </>
      )}

      {isAddCamelOpen && (
        <div className="fixed inset-0 z-[100] flex flex-col bg-[#3E2723]/70 backdrop-blur-lg animate-in fade-in duration-200 overflow-y-auto">
          <div className="flex justify-center items-start min-h-full p-4 lg:p-10">
            <div className="bg-[#FDFBF7] w-full max-w-2xl rounded-[2.5rem] overflow-hidden shadow-2xl relative my-auto">
              <div className="bg-[#3E2723] p-8 flex justify-between items-center text-white">
                <h2 className="text-2xl font-black">Camel Registry</h2>
                <button onClick={() => setIsAddCamelOpen(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg></button>
              </div>
              <form onSubmit={handleAddCamelSubmit} className="p-8 space-y-8">
                {formError && <div className="p-4 bg-red-50 text-red-600 rounded-xl text-xs font-bold shadow-sm">{formError}</div>}
                <section className="space-y-4">
                  <div className="flex flex-col items-center">
                    <div className="relative w-48 aspect-square rounded-[2rem] bg-white border-4 border-dashed border-[#F4E4BC] flex items-center justify-center group cursor-pointer overflow-hidden shadow-inner" onClick={() => fileInputRef.current?.click()}>
                      {imagePreview ? <img src={imagePreview} className="w-full h-full object-cover" /> : <ICONS.Plus className="w-10 h-10 text-gray-200 group-hover:text-[#D2691E] transition-colors" />}
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageChange} />
                    <p className="text-[10px] text-gray-400 font-black mt-2">Maximum Photo Size: 800KB</p>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Universal Chip ID (Required)</label>
                      <input name="chipNumber" required className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold" placeholder="Registry Serial" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Animal Name</label>
                      <input name="name" required className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold" placeholder="Identification Name" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Gender</label>
                      <select name="gender" required className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold">
                        <option value={Gender.MALE}>Male</option>
                        <option value={Gender.FEMALE}>Female</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Breed Category</label>
                      <select name="breed" className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold">
                        {BREEDS.map(b => <option key={b} value={b}>{b}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Birth Date</label>
                      <input name="dateOfBirth" type="date" required className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold" />
                    </div>
                  </div>
                </section>
                <section className="pt-6 border-t border-gray-100 space-y-6">
                  <div className="flex items-center gap-2"><div className="w-1.5 h-6 bg-[#D2691E] rounded-full"></div><h3 className="text-sm font-black text-[#3E2723] uppercase tracking-widest">Heritage & Lineage Data</h3></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center px-1 min-h-[1.5rem]">
                        <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Father (Sire) Chip</p>
                        {foundSire && <div className="flex items-center gap-1.5 animate-in fade-in slide-in-from-right-2"><ICONS.Check className="w-2.5 h-2.5 text-green-600" strokeWidth={5} /><span className="text-[9px] font-bold text-green-600 uppercase">Confirmed: {foundSire.name}</span></div>}
                        {sireError && <span className="text-[9px] font-bold text-red-500 uppercase animate-pulse">{sireError}</span>}
                        {sireChipQuery && !foundSire && !sireError && <span className="text-[9px] font-bold text-amber-500 uppercase">Manual Entry Required</span>}
                      </div>
                      <input name="sireChip" placeholder="Search Sire (Male) by Chip ID..." className={`w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 text-sm font-medium transition-all ${foundSire ? 'ring-2 ring-green-500 bg-green-50' : sireError ? 'ring-2 ring-red-500 bg-red-50' : 'focus:ring-[#D2691E]'}`} value={sireChipQuery} onChange={(e) => setSireChipQuery(e.target.value)} />
                      {!foundSire && !sireError && <input name="manualSireName" placeholder="Sire Full Name" className="w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-[#D2691E] text-sm font-medium animate-in fade-in" />}
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center px-1 min-h-[1.5rem]">
                        <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Mother (Dam) Chip</p>
                        {foundDam && <div className="flex items-center gap-1.5 animate-in fade-in slide-in-from-right-2"><ICONS.Check className="w-2.5 h-2.5 text-green-600" strokeWidth={5} /><span className="text-[9px] font-bold text-green-600 uppercase">Confirmed: {foundDam.name}</span></div>}
                        {damError && <span className="text-[9px] font-bold text-red-500 uppercase animate-pulse">{damError}</span>}
                        {damChipQuery && !foundDam && !damError && <span className="text-[9px] font-bold text-amber-500 uppercase">Manual Entry Required</span>}
                      </div>
                      <input name="damChip" placeholder="Search Dam (Female) by Chip ID..." className={`w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 text-sm font-medium transition-all ${foundDam ? 'ring-2 ring-green-500 bg-green-50' : damError ? 'ring-2 ring-red-500 bg-red-50' : 'focus:ring-blue-500'}`} value={damChipQuery} onChange={(e) => setDamChipQuery(e.target.value)} />
                      {!foundDam && !damError && <input name="manualDamName" placeholder="Dam Full Name" className="w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium animate-in fade-in" />}
                    </div>
                  </div>
                </section>
                <section className="pt-6 border-t border-gray-100 space-y-4">
                  <div className="flex items-center justify-between"><div className="flex items-center gap-2"><div className="w-1.5 h-6 bg-blue-500 rounded-full"></div><h3 className="text-sm font-black text-[#3E2723] uppercase tracking-widest">DNA & Registry Verification</h3></div><div className="flex items-center gap-6"><label className="flex items-center gap-2 cursor-pointer group"><input type="checkbox" checked={includeVerification} onChange={(e) => setIncludeVerification(e.target.checked)} className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500 transition-all" /><span className="text-xs font-black text-gray-500 uppercase group-hover:text-blue-600 transition-colors">Request Admin Verification?</span></label>{isAdmin && <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="isVerified" className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500" /><span className="text-xs font-black text-blue-600 uppercase">Apply Official Seal</span></label>}</div></div>
                  {includeVerification && <div className="space-y-4 animate-in fade-in slide-in-from-top-2"><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div className="space-y-1"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Inspector / Verified By</label><input name="verifiedBy" placeholder="Official Inspector Name" className="w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium" /></div><div className="space-y-1"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">DNA Laboratory Source</label><input name="dnaFacility" placeholder="Testing Facility Location" className="w-full px-5 py-3 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium" /></div></div><div className="space-y-1"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">Attachment (Click to upload Certificate/Proof)</label><div onClick={() => certInputRef.current?.click()} className={`w-full py-5 px-6 border-2 border-dashed rounded-[1.5rem] flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${certPreview ? 'border-green-400 bg-green-50 shadow-inner' : 'border-blue-200 hover:border-blue-400 bg-blue-50/30'}`}><div className={`p-4 rounded-full ${certPreview ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'}`}><ICONS.File className="w-8 h-8" /></div><div className="text-center"><p className={`text-sm font-black ${certPreview ? 'text-green-800' : 'text-blue-800'}`}>{certPreview ? certPreview.name : 'Click to Browse Certificate File'}</p><p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">{certPreview ? 'Attachment Ready' : 'Registry Proof (PDF/Image) Required'}</p></div>{certPreview && <div className="flex items-center gap-2 px-3 py-1 bg-green-600 text-white rounded-full text-[9px] font-black uppercase tracking-widest animate-bounce"><ICONS.Check className="w-3 h-3" strokeWidth={4} /> Stored in Registry</div>}</div><input type="file" ref={certInputRef} className="hidden" accept=".pdf,image/*" onChange={handleCertChange} /></div></div>}
                  {!includeVerification && <div className="p-6 bg-gray-50 rounded-[1.5rem] border border-dashed border-gray-200 text-center opacity-60"><p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-relaxed">Verification Inactive:<br/>No DNA documentation will be stored for this entry.</p></div>}
                  {includeVerification && !isAdmin && <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-start gap-3"><ICONS.Alert className="w-5 h-5 text-blue-600 shrink-0" /><p className="text-[10px] text-blue-700 font-bold leading-relaxed uppercase">Notice: Information and attachments will be permanently stored on your registry profile once submitted.</p></div>}
                </section>
                <button type="submit" className="w-full py-6 bg-[#D2691E] text-white rounded-[1.5rem] font-black text-lg uppercase tracking-[0.2em] shadow-2xl shadow-[#D2691E]/20 active:scale-95 transition-all">Submit & Store Registry Record</button>
              </form>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default App;
