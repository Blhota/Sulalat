
import { GoogleGenAI, Type } from "@google/genai";

// Initialization fixed to strictly follow guidelines: Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getCamelSummary = async (camel: any) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on the following camel data, write a 3-sentence professional summary for a registry catalog:
      Name: ${camel.name}
      Breed: ${camel.breed}
      Color: ${camel.color}
      Health: ${camel.healthStatus}
      Physical Description: ${camel.physicalDescription}
      Training: ${camel.trainingProgress}%
      Tags: ${camel.tags?.join(', ')}`,
      config: {
        systemInstruction: "You are an expert camel breeding and registry consultant. Your tone is professional, informative, and authoritative.",
        temperature: 0.7,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Summary unavailable at this time.";
  }
};

export const analyzeLineage = async (camel: any, sire?: any, dam?: any) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Perform a breeding heritage analysis for this camel:
      Subject: ${camel.name} (${camel.breed})
      Sire: ${sire ? sire.name + ' (' + sire.breed + ')' : (camel.manualSireName || 'Unknown')}
      Dam: ${dam ? dam.name + ' (' + dam.breed + ')' : (camel.manualDamName || 'Unknown')}
      
      Focus on potential hereditary traits, pedigree strength, and suggested breeding strategy.`,
      config: {
        systemInstruction: "You are a world-class camel geneticist and heritage analyst. Provide a sophisticated, concise analysis of lineage value.",
        temperature: 0.6,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Lineage API Error:", error);
    return "Heritage analysis currently processing...";
  }
};

export const suggestCamelTags = async (description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest 5 relevant short tags for a camel with this description: "${description}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      },
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini API Error:", error);
    return ["Majestic", "Healthy"];
  }
};
