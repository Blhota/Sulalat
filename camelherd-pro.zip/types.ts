
export enum HerdRole {
  OWNER = 'OWNER',
  MANAGER = 'MANAGER',
  VIEWER = 'VIEWER'
}

export enum UserRole {
  OWNER = 'OWNER',
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export enum Gender {
  MALE = 'MALE',
  FEMALE = 'FEMALE'
}

export enum VerificationStatus {
  PENDING = 'PENDING',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
  NOT_REQUESTED = 'NOT_REQUESTED'
}

export enum DocumentType {
  DNA_TEST = 'DNA_TEST',
  VACCINATION = 'VACCINATION',
  OTHER = 'OTHER'
}

export interface User {
  id: string;
  email: string;
  password?: string;
  name: string;
  role?: UserRole;
  herdId?: string;
  herdRole?: HerdRole;
  phone?: string;
  location?: string;
  createdAt: string;
}

export interface HerdMember {
  userId: string;
  name: string;
  email: string;
  role: HerdRole;
}

export interface Herd {
  id: string;
  name: string;
  ownerId: string;
  inviteCode: string;
  members: HerdMember[];
}

export interface CamelDocument {
  id: string;
  camelId: string;
  type: DocumentType;
  fileName: string;
  fileUrl: string;
  fileSize: number;
  uploadedBy: string;
  verifiedBy?: string;
  status: VerificationStatus;
  uploadDate: string;
}

export interface AdminField {
  label: string;
  value: string | number;
  confirmedByOwner: boolean;
  type: 'lineage' | 'competition' | 'vaccination' | 'breed' | 'history';
}

export interface Camel {
  id: string;
  registrationNumber: string;
  chipNumber: string;
  herdId: string;
  ownerId: string;
  ownerName: string;
  name: string;
  gender: Gender;
  dateOfBirth: string;
  breed: string;
  imageUrl?: string;
  color?: string;
  markings: string;
  physicalDescription: string;
  healthStatus: string;
  location?: string;
  verificationStatus: VerificationStatus;
  verifiedBy?: string;
  dnaFacility?: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  adminData: AdminField[];
  documents: CamelDocument[];
  behavioralNotes?: string;
  trainingProgress?: number;
  dietaryInfo?: string;
  tags?: string[];
  sireId?: string;
  damId?: string;
  manualSireName?: string;
  manualDamName?: string;
}
