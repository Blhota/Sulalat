
import React from 'react';
import { VerificationStatus } from '../types';

interface StatusBadgeProps {
  status: VerificationStatus;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  if (status === VerificationStatus.NOT_REQUESTED) return null;

  const styles = {
    [VerificationStatus.VERIFIED]: 'bg-blue-100 text-blue-700 border-blue-200',
    [VerificationStatus.PENDING]: 'bg-amber-100 text-amber-700 border-amber-200',
    [VerificationStatus.REJECTED]: 'bg-red-100 text-red-700 border-red-200',
    [VerificationStatus.NOT_REQUESTED]: '',
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${styles[status]}`}>
      {status}
    </span>
  );
};

export default StatusBadge;
