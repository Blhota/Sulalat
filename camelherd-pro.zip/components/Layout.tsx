
import React from 'react';
import { UserRole, User, HerdRole } from '../types';
import { COLORS, ICONS } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogoClick: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, activeTab, setActiveTab, onLogoClick }) => {
  if (!user) return <>{children}</>;

  const navItems = [
    { id: 'dashboard', label: 'Home', icon: ICONS.Camel },
    { id: 'directory', label: 'Herd', icon: ICONS.Search },
    { id: 'family', label: 'Family', icon: ICONS.Users },
    { id: 'admin', label: 'Verify', icon: ICONS.Check, adminOnly: true },
    { id: 'profile', label: 'Profile', icon: ICONS.File },
  ];

  const filteredNavItems = navItems.filter(item => {
    // Strictly gate the admin tab to only the ADMIN role (H@gmail)
    if (item.adminOnly && user.role !== UserRole.ADMIN) return false;
    // Hide Family tab for Admins as they don't belong to a single herd
    if (item.id === 'family' && user.role === UserRole.ADMIN) return false;
    return true;
  });

  return (
    <div className="flex h-screen bg-[#FDFBF7] overflow-hidden flex-col lg:flex-row">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 bg-[#3E2723] text-white flex-col shadow-xl shrink-0">
        <button 
          onClick={onLogoClick}
          className="p-6 flex items-center gap-3 hover:bg-white/5 transition-colors text-left w-full"
        >
          <div className="bg-[#D2691E] p-2 rounded-lg">
            <ICONS.Camel className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">CamelHerd Pro</span>
        </button>

        <nav className="flex-1 mt-6 px-4 space-y-2">
          {filteredNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                activeTab === item.id 
                ? 'bg-[#D2691E] text-white shadow-md' 
                : 'text-gray-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl mb-4">
            <div className="w-10 h-10 rounded-full bg-[#8A9A5B] flex items-center justify-center font-bold text-white shrink-0">
              {user.name.charAt(0)}
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-semibold truncate">{user.name}</span>
              <span className="text-xs text-gray-400 capitalize">{user.role?.toLowerCase()}</span>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full py-2 px-4 rounded-lg bg-red-900/30 text-red-200 hover:bg-red-800/40 transition-colors text-sm font-medium"
          >
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <header className="h-16 bg-white border-b flex items-center justify-between px-4 lg:px-8 sticky top-0 z-10 shadow-sm shrink-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={onLogoClick}
              className="lg:hidden bg-[#D2691E] p-1.5 rounded-lg active:scale-95 transition-transform"
            >
              <ICONS.Camel className="w-5 h-5 text-white" />
            </button>
            <h2 className="text-lg lg:text-xl font-bold text-[#3E2723] capitalize truncate">
              {activeTab.replace('-', ' ')}
            </h2>
          </div>
          <div className="flex items-center gap-2 lg:gap-4">
            <div className="relative hidden md:block">
               <input 
                  type="text" 
                  placeholder="Quick search..." 
                  className="pl-10 pr-4 py-2 bg-gray-100 border-none rounded-full text-sm focus:ring-2 focus:ring-[#D2691E] w-48 lg:w-64 outline-none"
               />
               <ICONS.Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
            </div>
            <button className="p-2 text-gray-400 hover:text-[#D2691E] relative">
              <ICONS.Alert className="w-6 h-6" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-8 pb-24 lg:pb-8">
          {children}
        </div>

        {/* Mobile Bottom Navigation */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-2 py-1.5 flex justify-around items-center z-50 shadow-[0_-4px_10px_rgba(0,0,0,0.05)] safe-area-bottom">
          {filteredNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all min-w-[64px] ${
                activeTab === item.id 
                ? 'text-[#D2691E]' 
                : 'text-gray-400'
              }`}
            >
              <item.icon className={`w-6 h-6 mb-1 ${activeTab === item.id ? 'stroke-[2.5px]' : 'stroke-2'}`} />
              <span className={`text-[10px] font-bold uppercase tracking-wider ${activeTab === item.id ? 'opacity-100' : 'opacity-60'}`}>
                {item.label}
              </span>
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
};

export default Layout;
