
import { createClient } from 'https://esm.sh/@supabase/supabase-js@^2.39.0';

// Replace these with your actual Supabase credentials from your dashboard
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/**
 * SQL SCHEMA FOR SUPABASE (Run this in your Supabase SQL Editor):
 * 
 * create table camels (
 *   id text primary key,
 *   data jsonb not null,
 *   owner_id text,
 *   herd_id text,
 *   updated_at timestamp with time zone default now()
 * );
 * 
 * create table herds (
 *   id text primary key,
 *   data jsonb not null
 * );
 * 
 * create table users (
 *   id text primary key,
 *   data jsonb not null
 * );
 */

export const syncCamelToCloud = async (camel: any) => {
  const { error } = await supabase
    .from('camels')
    .upsert({ 
      id: camel.id, 
      data: camel, 
      owner_id: camel.ownerId, 
      herd_id: camel.herdId,
      updated_at: new Date().toISOString()
    });
  return !error;
};

export const fetchAllCamels = async () => {
  const { data, error } = await supabase
    .from('camels')
    .select('data');
  if (error) return null;
  return data.map(item => item.data);
};

export const syncHerdToCloud = async (herd: any) => {
  const { error } = await supabase
    .from('herds')
    .upsert({ id: herd.id, data: herd });
  return !error;
};
