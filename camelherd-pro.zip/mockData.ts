
import { Camel, UserRole, VerificationStatus, DocumentType, User, Gender } from './types';

export const MOCK_USERS: User[] = [
  {
    id: 'u-admin-1',
    email: 'H@gmail',
    password: '1234',
    name: 'Chief Registrar',
    role: UserRole.ADMIN,
    phone: '+966 50 000 0000',
    location: 'Riyadh Registry Office',
    createdAt: '2024-01-01'
  },
  {
    id: 'u1',
    email: 'owner@example.com',
    password: 'password123',
    name: 'Ahmed Al-Saud',
    role: UserRole.OWNER,
    phone: '+966 50 123 4567',
    location: 'Riyadh, Saudi Arabia',
    createdAt: '2024-01-01'
  },
  {
    id: 'u2',
    email: 'admin@example.com',
    password: 'adminpassword',
    name: 'Mustafa Admin',
    role: UserRole.ADMIN,
    phone: '+966 55 987 6543',
    location: 'Dubai, UAE',
    createdAt: '2023-01-01'
  }
];

export const MOCK_CAMELS: Camel[] = [
  {
    id: 'c1',
    registrationNumber: 'CHIP-2024-001',
    chipNumber: 'CHIP-2024-001',
    herdId: 'h1',
    ownerId: 'u1',
    ownerName: 'Ahmed Al-Saud',
    name: 'Sahara Star',
    gender: Gender.FEMALE,
    dateOfBirth: '2020-05-15',
    breed: 'Majaheem',
    color: 'Dark Brown',
    markings: 'White spot on left ear',
    physicalDescription: 'Strong build, excellent posture, dark coat.',
    healthStatus: 'Healthy',
    location: 'Stable A-12',
    verificationStatus: VerificationStatus.VERIFIED,
    createdAt: '2024-02-10',
    updatedAt: '2024-03-01',
    adminData: [],
    documents: [
      {
        id: 'd1',
        camelId: 'c1',
        type: DocumentType.DNA_TEST,
        fileName: 'sahara_star_dna.pdf',
        fileUrl: '#',
        fileSize: 1024500,
        uploadedBy: 'u1',
        status: VerificationStatus.VERIFIED,
        uploadDate: '2024-02-11'
      }
    ]
  },
  {
    id: 'c2',
    registrationNumber: 'CHIP-2024-002',
    chipNumber: 'CHIP-2024-002',
    herdId: 'h1',
    ownerId: 'u1',
    ownerName: 'Ahmed Al-Saud',
    name: 'Desert Wind',
    gender: Gender.MALE,
    dateOfBirth: '2021-08-20',
    breed: 'Maghateer',
    color: 'Light Cream',
    markings: 'No major markings',
    physicalDescription: 'Elegant, tall, light-colored.',
    healthStatus: 'Healthy',
    location: 'Stable B-05',
    verificationStatus: VerificationStatus.PENDING,
    createdAt: '2024-03-05',
    updatedAt: '2024-03-05',
    adminData: [],
    documents: []
  }
];
