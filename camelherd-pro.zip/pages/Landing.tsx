
import React, { useState } from 'react';
import { ICONS, COLORS } from '../constants';

interface LandingProps {
  onLogin: () => void;
  onRegister: () => void;
  onChipLookup: (chip: string) => void;
}

const Landing: React.FC<LandingProps> = ({ onLogin, onRegister, onChipLookup }) => {
  const [chipInput, setChipInput] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (chipInput.trim()) {
      onChipLookup(chipInput.trim());
      setChipInput('');
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#3E2723] selection:bg-[#D2691E]/20">
      {/* Navigation */}
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-2 lg:gap-3">
          <div className="bg-[#D2691E] p-2 rounded-xl shadow-lg shadow-[#D2691E]/20">
            <ICONS.Camel className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight">CamelHerd Pro</span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={onLogin}
            className="hidden md:block text-sm font-bold text-gray-500 hover:text-[#3E2723] transition-colors"
          >
            Sign In
          </button>
          <button 
            onClick={onLogin}
            className="px-6 py-2.5 bg-[#3E2723] text-white rounded-xl font-bold text-sm hover:bg-black transition-all active:scale-95"
          >
            Login
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="px-6 py-12 lg:py-24 max-w-7xl mx-auto text-center flex flex-col items-center">
        <div className="inline-block px-4 py-1.5 bg-[#F4E4BC] text-[#D2691E] rounded-full text-xs font-black uppercase tracking-[0.2em] mb-6 animate-fade-in">
          Public Registry Lookup
        </div>
        <h1 className="text-4xl lg:text-7xl font-black mb-8 leading-[1.1] tracking-tight">
          Verify Heritage <br className="hidden lg:block" />
          <span className="text-[#D2691E]">Instantly & Securely</span>
        </h1>
        <p className="text-lg lg:text-xl text-[#3E2723]/60 max-w-2xl mx-auto mb-12 leading-relaxed font-medium">
          Enter a camel's unique chip identifier to view its verified registry data, DNA status, and lineage history without an account.
        </p>

        {/* New Public Search Bar */}
        <form onSubmit={handleSearch} className="w-full max-w-2xl mb-16 relative group">
           <div className="bg-[#3E2723] p-2 rounded-[2rem] shadow-2xl flex flex-col sm:flex-row gap-2 border border-white/10">
              <div className="relative flex-1">
                <input 
                  type="text" 
                  value={chipInput}
                  onChange={(e) => setChipInput(e.target.value)}
                  placeholder="Scan or Enter Chip / Serial No." 
                  className="w-full bg-white/5 border-none px-12 py-5 rounded-[1.5rem] text-white font-black text-lg outline-none placeholder:text-white/20 transition-all"
                />
                <ICONS.Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D2691E]" />
              </div>
              <button 
                type="submit"
                className="px-8 py-5 bg-[#D2691E] text-white rounded-[1.5rem] font-black uppercase tracking-widest text-sm hover:bg-white hover:text-[#3E2723] transition-all active:scale-95 shadow-lg shadow-[#D2691E]/20"
              >
                Lookup Record
              </button>
           </div>
           <p className="mt-4 text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center justify-center gap-2">
             <ICONS.Check className="w-3 h-3 text-[#8A9A5B]" strokeWidth={4} /> Open Registry Standards • Global Verification
           </p>
        </form>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={onRegister}
            className="w-full sm:w-auto px-10 py-5 bg-[#3E2723] text-white rounded-2xl font-black text-lg hover:bg-black transition-all shadow-xl shadow-[#3E2723]/10 active:scale-95"
          >
            Start Managing Free
          </button>
          <div className="flex items-center gap-4 px-6 py-4 bg-white border border-gray-100 rounded-2xl shadow-sm">
             <div className="flex -space-x-3">
                {[1,2,3].map(i => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-[#8A9A5B] flex items-center justify-center text-[10px] text-white font-bold">U{i}</div>
                ))}
             </div>
             <span className="text-xs font-bold text-gray-500">+500 Owners Joined</span>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="px-6 py-16 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black mb-4">Everything you need</h2>
            <p className="text-gray-500 font-medium">Built specifically for the unique needs of camel breeding.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="p-8 rounded-3xl bg-[#FDFBF7] border border-gray-100 hover:border-[#D2691E]/30 transition-all group">
              <div className="w-14 h-14 bg-[#D2691E]/10 rounded-2xl flex items-center justify-center text-[#D2691E] mb-6 group-hover:scale-110 transition-transform">
                <ICONS.Check className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#3E2723]">DNA Verification</h3>
              <p className="text-[#3E2723]/60 leading-relaxed text-sm">Upload DNA certificates and have them verified by official admins to prove your camel's pedigree.</p>
            </div>

            <div className="p-8 rounded-3xl bg-[#FDFBF7] border border-gray-100 hover:border-[#D2691E]/30 transition-all group">
              <div className="w-14 h-14 bg-[#8A9A5B]/10 rounded-2xl flex items-center justify-center text-[#8A9A5B] mb-6 group-hover:scale-110 transition-transform">
                <ICONS.Alert className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#3E2723]">Health Monitoring</h3>
              <p className="text-[#3E2723]/60 leading-relaxed text-sm">Track vaccinations, veterinarian visits, and overall health indexes with simple mobile updates.</p>
            </div>

            <div className="p-8 rounded-3xl bg-[#FDFBF7] border border-gray-100 hover:border-[#D2691E]/30 transition-all group">
              <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-6 group-hover:scale-110 transition-transform">
                <ICONS.File className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#3E2723]">Official Registry</h3>
              <p className="text-[#3E2723]/60 leading-relaxed text-sm">Connect directly with government administrators to manage official breed records and registration numbers.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-12 border-t border-gray-100 text-center text-sm text-gray-400 font-medium">
        <p>© 2024 CamelHerd Pro. All rights reserved. Desert-Built for the World.</p>
      </footer>
    </div>
  );
};

export default Landing;
