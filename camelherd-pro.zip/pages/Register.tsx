
import React, { useState } from 'react';
import { ICONS } from '../constants';

interface RegisterProps {
  onRegister: (data: { name: string; email: string; pass: string }) => Promise<{ success: boolean; message?: string }>;
  onBack: () => void;
}

const Register: React.FC<RegisterProps> = ({ onRegister, onBack }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    
    const result = await onRegister({ name, email, pass: password });
    
    if (!result.success) {
      setError(result.message || "Registration failed. Please try again.");
      setIsLoading(false);
    }
    // Success case is handled in App.tsx by changing state/view
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl shadow-[#3E2723]/5 p-8 lg:p-12 border border-gray-100 animate-in zoom-in-95 duration-300">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-[#D2691E] rounded-2xl mx-auto flex items-center justify-center text-white shadow-lg shadow-[#D2691E]/20 mb-4">
            <ICONS.Camel className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-black text-[#3E2723]">Join the Herd</h1>
          <p className="text-gray-500 mt-2 font-medium">Create your profile to get started</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
            <ICONS.Alert className="w-5 h-5 text-red-500 shrink-0" />
            <p className="text-xs font-bold text-red-600">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Full Name</label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Sultan Al-Maktoum"
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] transition-all font-medium text-sm disabled:opacity-50"
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@provider.com"
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] transition-all font-medium text-sm disabled:opacity-50"
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] transition-all font-medium text-sm disabled:opacity-50"
              disabled={isLoading}
            />
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full py-5 bg-[#3E2723] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all active:scale-95 shadow-xl shadow-[#3E2723]/10 mt-4 disabled:bg-gray-400 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Creating...
              </>
            ) : "Create Account"}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={onBack}
            className="text-xs font-bold text-gray-400 hover:text-[#D2691E] transition-colors disabled:opacity-50"
            disabled={isLoading}
          >
            Already have an account? Sign In
          </button>
        </div>
      </div>
      <p className="mt-8 text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">Desert-Powered • Secure Data</p>
    </div>
  );
};

export default Register;
