
import React from 'react';
import { ICONS } from '../constants';
import { Herd, HerdRole, User } from '../types';

interface HerdFamilyProps {
  user: User;
  herd: Herd | null;
  onJoinHerd: (code: string) => void;
  onCreateHerd: (name: string) => void;
}

const HerdFamily: React.FC<HerdFamilyProps> = ({ user, herd, onJoinHerd, onCreateHerd }) => {
  const [joinCode, setJoinCode] = React.useState('');
  const [herdName, setHerdName] = React.useState('');
  const [view, setView] = React.useState<'choice' | 'create' | 'join'>('choice');

  if (!herd) {
    return (
      <div className="max-w-4xl mx-auto py-12 px-4 space-y-12 animate-in fade-in zoom-in-95 duration-500">
        <div className="text-center space-y-6">
          <div className="inline-block p-4 bg-[#F4E4BC] rounded-[2rem] text-[#D2691E] shadow-xl shadow-[#D2691E]/5 mb-2">
            <ICONS.Users className="w-12 h-12" />
          </div>
          <h2 className="text-3xl lg:text-5xl font-black text-[#3E2723] tracking-tight">One last step, {user.name.split(' ')[0]}</h2>
          <p className="text-gray-500 max-w-md mx-auto font-medium text-lg leading-relaxed">To start managing animals, you need to establish your heritage. Choose how you want to proceed.</p>
        </div>

        {view === 'choice' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <button 
              onClick={() => setView('create')}
              className="group bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-200/50 flex flex-col items-center text-center space-y-6 hover:border-[#D2691E] hover:shadow-[#D2691E]/5 transition-all active:scale-[0.98]"
            >
              <div className="w-20 h-20 bg-[#D2691E]/10 rounded-3xl flex items-center justify-center text-[#D2691E] group-hover:scale-110 transition-transform">
                <ICONS.Plus className="w-10 h-10" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-[#3E2723]">Create New Herd</h3>
                <p className="text-gray-500 mt-2 text-sm font-medium">Start fresh and invite your family members later.</p>
              </div>
              <div className="w-full py-4 bg-[#D2691E] text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-[#D2691E]/20">
                Let's Begin
              </div>
            </button>

            <button 
              onClick={() => setView('join')}
              className="group bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-200/50 flex flex-col items-center text-center space-y-6 hover:border-[#8A9A5B] hover:shadow-[#8A9A5B]/5 transition-all active:scale-[0.98]"
            >
              <div className="w-20 h-20 bg-[#8A9A5B]/10 rounded-3xl flex items-center justify-center text-[#8A9A5B] group-hover:scale-110 transition-transform">
                <ICONS.Link className="w-10 h-10" />
              </div>
              <div>
                <h3 className="text-2xl font-black text-[#3E2723]">Join Family</h3>
                <p className="text-gray-500 mt-2 text-sm font-medium">Use an invitation code from an existing owner.</p>
              </div>
              <div className="w-full py-4 bg-[#8A9A5B] text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-[#8A9A5B]/20">
                Enter Code
              </div>
            </button>
          </div>
        )}

        {view === 'create' && (
          <div className="max-w-md mx-auto bg-white p-10 rounded-[3rem] border border-gray-100 shadow-2xl space-y-8 animate-in slide-in-from-bottom-8">
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-black">Name your Herd</h3>
              <p className="text-gray-400 text-sm font-bold uppercase tracking-widest">Establish your legacy</p>
            </div>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="e.g. Al-Nasser Royal Stables" 
                className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold text-lg"
                autoFocus
                value={herdName}
                onChange={(e) => setHerdName(e.target.value)}
              />
              <button 
                onClick={() => onCreateHerd(herdName)}
                disabled={!herdName.trim()}
                className="w-full py-5 bg-[#D2691E] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-[#A0522D] transition-all disabled:opacity-50 shadow-xl shadow-[#D2691E]/20"
              >
                Create Heritage &rarr;
              </button>
              <button 
                onClick={() => setView('choice')}
                className="w-full py-2 text-xs font-black text-gray-400 uppercase tracking-widest hover:text-gray-600"
              >
                &larr; Go Back
              </button>
            </div>
          </div>
        )}

        {view === 'join' && (
          <div className="max-w-md mx-auto bg-white p-10 rounded-[3rem] border border-gray-100 shadow-2xl space-y-8 animate-in slide-in-from-bottom-8">
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-black">Enter Invitation</h3>
              <p className="text-gray-400 text-sm font-bold uppercase tracking-widest">Connect with your family</p>
            </div>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Code (e.g. SAUD77)" 
                className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#8A9A5B] font-black text-2xl text-center uppercase tracking-[0.5em] placeholder:tracking-normal placeholder:font-bold placeholder:text-lg"
                autoFocus
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
              />
              <button 
                onClick={() => onJoinHerd(joinCode)}
                disabled={!joinCode.trim()}
                className="w-full py-5 bg-[#8A9A5B] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-green-800 transition-all disabled:opacity-50 shadow-xl shadow-[#8A9A5B]/20"
              >
                Join Now &rarr;
              </button>
              <button 
                onClick={() => setView('choice')}
                className="w-full py-2 text-xs font-black text-gray-400 uppercase tracking-widest hover:text-gray-600"
              >
                &larr; Go Back
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  const isOwner = user.herdRole === HerdRole.OWNER;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(herd.inviteCode)}&color=3E2723&bgcolor=FDFBF7`;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        {/* Invite Card */}
        <div className="w-full md:w-80 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm text-center flex flex-col items-center space-y-6">
            <h3 className="text-lg font-bold text-[#3E2723]">Invite Members</h3>
            <div className="p-3 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 group relative">
              <img 
                src={qrUrl} 
                alt="Invite QR" 
                className="w-40 h-40 rounded-xl transition-all group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-white/40 backdrop-blur-[2px] rounded-xl">
                 <span className="text-[10px] font-black uppercase text-[#3E2723] bg-white px-3 py-1 rounded-full shadow-sm">Scan to Join</span>
              </div>
            </div>
            <div className="w-full space-y-2">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Invite Code</p>
              <div className="bg-[#F4E4BC] py-3 px-6 rounded-xl text-xl font-black text-[#3E2723] tracking-[0.3em] border border-[#E8D4A2]">
                {herd.inviteCode}
              </div>
            </div>
            <button 
              onClick={() => {
                navigator.clipboard.writeText(herd.inviteCode);
                alert("Invite code copied to clipboard!");
              }}
              className="w-full flex items-center justify-center gap-2 text-xs font-black text-[#D2691E] uppercase tracking-wider active:scale-95 transition-transform"
            >
              <ICONS.Link className="w-4 h-4" /> Copy Join Link
            </button>
          </div>

          <div className="bg-[#3E2723] p-6 rounded-[2rem] text-white shadow-xl shadow-[#3E2723]/10">
            <p className="text-xs text-white/60 font-medium leading-relaxed">Share this digital key with your family. Any member with this code can view the herd history and register new animals.</p>
          </div>
        </div>

        {/* Members List */}
        <div className="flex-1 space-y-6 w-full">
          <div className="flex justify-between items-center px-2">
            <h2 className="text-2xl font-black text-[#3E2723]">{herd.name} Family</h2>
            <span className="px-3 py-1 bg-gray-100 text-gray-500 text-[10px] font-black uppercase tracking-widest rounded-full">{herd.members.length} Members</span>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm overflow-hidden">
            <div className="divide-y divide-gray-50">
              {herd.members.map((member) => (
                <div key={member.userId} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center text-[#D2691E] font-black text-lg shadow-inner">
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-[#3E2723]">{member.name} {member.userId === user.id && "(You)"}</p>
                      <p className="text-xs text-gray-400 font-medium">{member.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider border ${
                      member.role === HerdRole.OWNER ? 'bg-orange-100 text-[#D2691E] border-orange-200' :
                      member.role === HerdRole.MANAGER ? 'bg-blue-100 text-blue-700 border-blue-200' :
                      'bg-gray-100 text-gray-500 border-gray-200'
                    }`}>
                      {member.role}
                    </span>
                    {isOwner && member.userId !== user.id && (
                      <button className="p-2 text-gray-300 hover:text-red-500 transition-colors">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HerdFamily;
