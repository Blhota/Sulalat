
import React, { useState } from 'react';
import { Camel, VerificationStatus, UserRole, User, Gender } from '../types';
import { ICONS } from '../constants';
import StatusBadge from '../components/StatusBadge';
import { analyzeLineage } from '../geminiService';

interface CamelProfileProps {
  camel: Camel;
  user: User | null; 
  onUpdate: (updatedCamel: Camel) => void;
  onBack: () => void;
  camels: Camel[];
  onViewCamel: (camel: Camel) => void;
}

const CamelProfile: React.FC<CamelProfileProps> = ({ camel, user, onUpdate, onBack, camels, onViewCamel }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'lineage'>('info');
  const [lineageAnalysis, setLineageAnalysis] = useState<string>('');
  const [isAnalysisModalOpen, setIsAnalysisModalOpen] = useState(false);
  const [analysisTarget, setAnalysisTarget] = useState<Camel | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);

  const isAdmin = user?.role === UserRole.ADMIN;
  const isGuest = !user;

  const handleStatusChange = (status: VerificationStatus) => {
    if (isAdmin) {
      onUpdate({ ...camel, verificationStatus: status });
    }
  };

  const sire = camel.sireId ? camels.find(c => c.id === camel.sireId) : null;
  const dam = camel.damId ? camels.find(c => c.id === camel.damId) : null;
  
  // Find all offspring where the current camel is either Sire or Dam
  const offspring = camels.filter(c => c.sireId === camel.id || c.damId === camel.id);

  const openLineageAnalysis = async (target: Camel) => {
    setAnalysisTarget(target);
    setIsAnalysisModalOpen(true);
    setIsLoadingAnalysis(true);
    const targetSire = target.sireId ? camels.find(c => c.id === target.sireId) : null;
    const targetDam = target.damId ? camels.find(c => c.id === target.damId) : null;
    const analysis = await analyzeLineage(target, targetSire, targetDam);
    setLineageAnalysis(analysis || "Analysis unavailable.");
    setIsLoadingAnalysis(false);
  };

  const camelQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(`CamelID:${camel.chipNumber}`)}&color=3E2723&bgcolor=FFFFFF`;

  const ParentCard = ({ parent, manualName, label }: { parent: Camel | null, manualName?: string, label: string }) => (
    <div className="flex flex-col items-center space-y-3 p-6 bg-white rounded-2xl border border-gray-100 shadow-sm w-full animate-in fade-in slide-in-from-top-2">
       <div className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{label}</div>
       {parent ? (
         <button onClick={() => onViewCamel(parent)} className="flex flex-col items-center group">
           <div className="relative w-16 h-16 rounded-2xl bg-orange-50 flex items-center justify-center text-[#D2691E] group-hover:scale-110 transition-all shadow-inner mb-2 overflow-hidden border-2 border-white">
              {parent.imageUrl ? <img src={parent.imageUrl} alt={parent.name} className="w-full h-full object-cover" /> : <ICONS.Camel className="w-8 h-8" />}
              {parent.verificationStatus === VerificationStatus.VERIFIED && (
                <div className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-0.5 border border-white shadow-sm">
                   <ICONS.Check className="w-2 h-2 text-white" strokeWidth={5} />
                </div>
              )}
           </div>
           <p className="font-bold text-[#3E2723] group-hover:text-[#D2691E] transition-colors text-center truncate w-full px-2">{parent.name}</p>
         </button>
       ) : manualName ? (
         <div className="flex flex-col items-center">
           <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center text-gray-400 shadow-inner mb-2 border-2 border-dashed border-gray-100"><ICONS.Users className="w-6 h-6" /></div>
           <p className="font-bold text-[#3E2723]">{manualName}</p>
         </div>
       ) : (
         <div className="flex flex-col items-center opacity-40">
           <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center text-gray-400 shadow-inner mb-2 border-2 border-dashed border-200"><ICONS.Plus className="w-6 h-6" /></div>
           <p className="font-bold text-gray-400 italic">Unknown</p>
         </div>
       )}
    </div>
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 pb-10">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-[#D2691E] font-bold py-2 px-1 hover:underline active:scale-95 transition-transform">
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
        {isGuest ? 'Back to Registry Search' : 'Back to Herd'}
      </button>

      {/* Profile Header Card */}
      <div className="bg-white rounded-[2.5rem] p-6 lg:p-10 border border-gray-100 shadow-xl flex flex-col md:flex-row gap-8 items-center text-center md:text-left relative overflow-hidden">
        {camel.verificationStatus === VerificationStatus.VERIFIED && (
          <div className="absolute top-8 right-8 hidden lg:flex flex-col items-center animate-in zoom-in-50 duration-700">
             <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-blue-500/20 border-4 border-white">
                <ICONS.Check className="w-8 h-8" strokeWidth={4} />
             </div>
             <p className="mt-2 text-[10px] font-black text-blue-600 uppercase tracking-widest">Verified Heritage</p>
          </div>
        )}

        <div className="relative w-32 h-32 lg:w-40 lg:h-40 rounded-[3rem] bg-[#F4E4BC] flex items-center justify-center text-[#D2691E] shrink-0 shadow-2xl overflow-hidden border-4 border-white">
          {camel.imageUrl ? <img src={camel.imageUrl} alt={camel.name} className="w-full h-full object-cover" /> : <ICONS.Camel className="w-16 h-16 lg:w-20 lg:h-20" />}
          {camel.verificationStatus === VerificationStatus.VERIFIED && (
            <div className="absolute bottom-4 right-4 bg-blue-500 rounded-full p-2 border-4 border-white shadow-xl lg:hidden">
               <ICONS.Check className="w-4 h-4 text-white" strokeWidth={5} />
            </div>
          )}
        </div>
        
        <div className="flex-1 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center gap-4 items-center">
            <h1 className="text-3xl lg:text-4xl font-black text-[#3E2723] leading-none">{camel.name}</h1>
            <div className="flex items-center gap-2">
               <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${camel.gender === Gender.MALE ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'}`}>
                 {camel.gender}
               </span>
               <StatusBadge status={camel.verificationStatus} />
            </div>
          </div>
          <div className="flex flex-col gap-1">
             <p className="text-[#D2691E] font-black uppercase tracking-[0.2em] text-xs">{camel.breed} Breed</p>
             <p className="text-gray-400 font-bold text-sm">Chip ID: {camel.chipNumber}</p>
          </div>
        </div>
        
        {isAdmin && camel.verificationStatus === VerificationStatus.PENDING && (
          <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100 w-full md:w-auto">
             <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest text-center mb-4">DNA Review Terminal</p>
             <div className="flex flex-col gap-2">
                <button 
                  onClick={() => handleStatusChange(VerificationStatus.VERIFIED)}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-2xl text-xs font-black uppercase tracking-widest bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 active:scale-95"
                >
                  <ICONS.Check className="w-4 h-4" strokeWidth={4} /> Approve Seal
                </button>
                <button 
                  onClick={() => handleStatusChange(VerificationStatus.REJECTED)}
                  className="w-full px-6 py-4 text-xs font-black text-red-400 uppercase tracking-widest hover:text-red-600 transition-colors"
                >
                  Reject Review
                </button>
             </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 p-1 bg-gray-100 rounded-2xl w-fit">
        {[{ id: 'info', label: 'Registry Info' }, { id: 'lineage', label: 'Heritage Tree' }].map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`px-8 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === tab.id ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}>
            {tab.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        {activeTab === 'info' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-[2.5rem] p-8 lg:p-10 border border-gray-100 shadow-sm space-y-10">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  <div><p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Birth Date</p><p className="font-bold text-[#3E2723]">{camel.dateOfBirth}</p></div>
                  <div><p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Health Status</p><p className="font-bold text-[#3E2723]">{camel.healthStatus}</p></div>
                  <div><p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Registry Loc</p><p className="font-bold text-[#3E2723]">{camel.location || 'Desert Station'}</p></div>
                </div>

                <div className="pt-8 border-t border-gray-100 space-y-6">
                  <div className="flex items-center gap-2">
                    <div className="w-1.5 h-6 bg-blue-500 rounded-full"></div>
                    <h3 className="text-sm font-black text-[#3E2723] uppercase tracking-widest">Official DNA Authentication</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Registry DNA Facility</p>
                        <p className="font-bold text-[#3E2723]">{camel.dnaFacility || "No verified facility recorded"}</p>
                     </div>
                     <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Verified By Inspector</p>
                        <p className="font-bold text-[#3E2723]">{camel.verifiedBy || "No official inspector assigned"}</p>
                     </div>
                  </div>
                </div>
                
                <div className="space-y-4 pt-6 border-t border-gray-50">
                  <h3 className="text-sm font-black text-[#3E2723] uppercase tracking-widest">Registry Certificates</h3>
                  <div className="grid grid-cols-1 gap-3">
                     {camel.documents && camel.documents.length > 0 ? camel.documents.map(doc => (
                       <div key={doc.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100">
                          <div className="flex items-center gap-3">
                             <div className="p-2 bg-white rounded-lg text-blue-600 shadow-sm"><ICONS.File className="w-5 h-5" /></div>
                             <p className="text-xs font-black text-[#3E2723]">{doc.fileName}</p>
                          </div>
                          <div className="flex items-center gap-3">
                             {doc.fileUrl !== '#' && (
                               <a 
                                 href={doc.fileUrl} 
                                 target="_blank" 
                                 rel="noopener noreferrer"
                                 className="text-[10px] font-black text-blue-600 uppercase border border-blue-200 px-3 py-1 rounded-lg hover:bg-blue-50 transition-colors"
                               >
                                 View Proof
                               </a>
                             )}
                             <StatusBadge status={doc.status} />
                          </div>
                       </div>
                     )) : <p className="text-xs font-bold text-gray-400 italic">No biological certificates attached.</p>}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] p-8 border border-gray-100 shadow-sm flex flex-col items-center text-center space-y-6">
              <h3 className="text-sm font-black text-[#3E2723] uppercase tracking-widest">Passport QR Index</h3>
              <div className="p-4 bg-white rounded-[2rem] shadow-2xl border border-gray-50 group">
                <img src={camelQrUrl} alt="Passport QR" className="w-48 h-48 group-hover:scale-105 transition-transform" />
              </div>
              <p className="text-[10px] text-gray-400 font-medium px-4">Registry terminal ID. Verified breed status is only confirmed by the official blue DNA seal.</p>
            </div>
          </div>
        )}

        {activeTab === 'lineage' && (
          <div className="space-y-8 animate-in fade-in duration-500">
             {/* Lineage Tree Section */}
             <div className="bg-white rounded-[2.5rem] p-10 border border-gray-100 shadow-sm space-y-12">
                <div className="text-center space-y-2"><h3 className="text-2xl font-black text-[#3E2723]">Biological Heritage</h3><p className="text-gray-400 text-xs font-black uppercase tracking-[0.3em]">Pedigree Lineage Tree</p></div>
                <div className="flex flex-col items-center">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-2xl">
                      <ParentCard parent={sire} manualName={camel.manualSireName} label="Sire (Father)" />
                      <ParentCard parent={dam} manualName={camel.manualDamName} label="Dam (Mother)" />
                   </div>
                   <div className="relative mt-12 p-8 bg-[#3E2723] text-white rounded-[3rem] border-8 border-[#F4E4BC] shadow-2xl flex flex-col items-center min-w-[280px]">
                      <h4 className="text-xl font-black">{camel.name}</h4>
                      <p className="text-white/40 text-[10px] font-black uppercase tracking-widest mt-1">Registry Node</p>
                      {camel.verificationStatus === VerificationStatus.VERIFIED && (
                        <div className="absolute -top-4 -right-4 bg-blue-500 rounded-full p-2 border-4 border-[#FDFBF7] shadow-lg">
                           <ICONS.Check className="w-6 h-6 text-white" strokeWidth={5} />
                        </div>
                      )}
                   </div>
                </div>
             </div>

             {/* Offspring List Section */}
             <div className="bg-white rounded-[2.5rem] p-10 border border-gray-100 shadow-sm space-y-8">
                <div className="flex items-center justify-between border-b border-gray-50 pb-6">
                   <div>
                      <h3 className="text-xl font-black text-[#3E2723]">Progeny & Offspring</h3>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Verified Next-Gen Records</p>
                   </div>
                   <div className="px-4 py-2 bg-gray-50 rounded-xl text-xs font-black text-[#D2691E] border border-gray-100">
                      Total: {offspring.length}
                   </div>
                </div>

                {offspring.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {offspring.map((child) => (
                      <button 
                        key={child.id}
                        onClick={() => onViewCamel(child)}
                        className="group flex items-center gap-4 p-4 bg-gray-50/50 hover:bg-white border border-transparent hover:border-[#D2691E]/20 rounded-2xl transition-all text-left shadow-sm hover:shadow-md"
                      >
                         <div className="relative w-12 h-12 rounded-xl bg-white flex items-center justify-center text-[#D2691E] shrink-0 shadow-inner overflow-hidden border border-gray-100">
                            {child.imageUrl ? (
                              <img src={child.imageUrl} className="w-full h-full object-cover" />
                            ) : (
                              <ICONS.Camel className="w-6 h-6" />
                            )}
                         </div>
                         <div className="overflow-hidden">
                            <p className="font-black text-[#3E2723] text-sm truncate group-hover:text-[#D2691E] transition-colors">{child.name}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                               <span className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded-md ${child.gender === Gender.MALE ? 'bg-blue-100 text-blue-600' : 'bg-pink-100 text-pink-600'}`}>
                                 {child.gender}
                               </span>
                               <span className="text-[9px] text-gray-400 font-bold truncate">{child.breed}</span>
                            </div>
                         </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 flex flex-col items-center justify-center text-center opacity-50 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-100">
                     <ICONS.Users className="w-10 h-10 text-gray-200 mb-2" />
                     <p className="text-xs font-black text-gray-400 uppercase tracking-widest">No Progeny Recorded</p>
                  </div>
                )}
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CamelProfile;
