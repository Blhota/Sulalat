
import React, { useState } from 'react';
import { ICONS } from '../constants';

interface AuthProps {
  onLogin: (email: string, pass: string) => Promise<boolean>;
  onRegister: () => void;
  onBack: () => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, onRegister, onBack }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const success = await onLogin(email, password);
      if (!success) {
        setError("Invalid email or password. Please try again.");
      }
    } catch (err) {
      setError("An unexpected error occurred. Please check your connection.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl shadow-[#3E2723]/5 p-8 lg:p-12 border border-gray-100 animate-in zoom-in-95 duration-300">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-[#3E2723] rounded-2xl mx-auto flex items-center justify-center text-white shadow-lg shadow-[#3E2723]/20 mb-4">
            <ICONS.Camel className="w-10 h-10" />
          </div>
          <h1 className="text-3xl font-black text-[#3E2723]">Welcome Back</h1>
          <p className="text-gray-500 mt-2 font-medium">Access your herd management suite</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
            <ICONS.Alert className="w-5 h-5 text-red-500 shrink-0" />
            <p className="text-xs font-bold text-red-600">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. sultan@herdpro.com"
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] transition-all font-medium text-sm disabled:opacity-50"
              disabled={isLoading}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Password</label>
              <button type="button" className="text-[10px] font-bold text-[#D2691E] uppercase">Forgot?</button>
            </div>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-5 py-4 bg-gray-50 border-none rounded-2xl outline-none focus:ring-2 focus:ring-[#D2691E] transition-all font-medium text-sm disabled:opacity-50"
              disabled={isLoading}
            />
          </div>

          <div className="flex items-center gap-2 px-1">
            <input type="checkbox" id="remember" className="rounded border-gray-300 text-[#D2691E] focus:ring-[#D2691E]" />
            <label htmlFor="remember" className="text-xs font-bold text-gray-500">Stay signed in</label>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full py-5 bg-[#D2691E] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-[#A0522D] transition-all active:scale-95 shadow-xl shadow-[#D2691E]/20 mt-4 disabled:bg-gray-400 flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Authenticating...
              </>
            ) : "Sign In"}
          </button>
        </form>

        <div className="mt-10 pt-6 border-t border-gray-50 flex flex-col gap-4 text-center">
          <button 
            onClick={onRegister}
            className="text-xs font-bold text-gray-500 hover:text-[#D2691E] transition-colors"
          >
            Don't have an account? <span className="text-[#D2691E]">Create one</span>
          </button>
          <button 
            onClick={onBack}
            className="text-[10px] font-black text-gray-400 uppercase tracking-widest"
          >
            ← Back to Home
          </button>
        </div>
      </div>
      <p className="mt-8 text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">Secure Authentication • CamelHerd Pro</p>
    </div>
  );
};

export default Auth;
