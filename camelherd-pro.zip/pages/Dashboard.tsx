
import React, { useState } from 'react';
import { User, Camel, VerificationStatus } from '../types';
import { ICONS } from '../constants';
import StatusBadge from '../components/StatusBadge';

interface DashboardProps {
  user: User;
  camels: Camel[];
  onAddCamel: () => void;
  onViewCamel: (camel: Camel) => void;
  onNavigateToFamily: () => void;
  onChipLookup: (chip: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, camels, onAddCamel, onViewCamel, onNavigateToFamily, onChipLookup }) => {
  const [chipInput, setChipInput] = useState('');

  const handleChipSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chipInput.trim()) return;
    onChipLookup(chipInput.trim());
    setChipInput('');
  };

  if (!user.herdId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 animate-in fade-in duration-500">
        <div className="w-24 h-24 bg-[#F4E4BC] rounded-[2rem] flex items-center justify-center text-[#D2691E] shadow-xl shadow-[#D2691E]/10">
          <ICONS.Users className="w-12 h-12" />
        </div>
        <div className="max-w-md space-y-2">
          <h2 className="text-2xl font-black text-[#3E2723]">Almost there!</h2>
          <p className="text-gray-500 font-medium">You need to be part of a herd before you can manage animals. Join your family's herd or create a new one to get started.</p>
        </div>
        <button 
          onClick={onNavigateToFamily}
          className="px-8 py-4 bg-[#D2691E] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-[#A0522D] transition-all shadow-xl shadow-[#D2691E]/20"
        >
          Set up my Herd
        </button>
      </div>
    );
  }

  const stats = [
    { label: 'Total', value: camels.length, icon: ICONS.Camel, color: 'bg-orange-100 text-orange-600' },
    { label: 'Verified', value: camels.filter(c => c.verificationStatus === VerificationStatus.VERIFIED).length, icon: ICONS.Check, color: 'bg-blue-100 text-blue-600' },
    { label: 'Pending', value: camels.filter(c => c.verificationStatus === VerificationStatus.PENDING).length, icon: ICONS.Alert, color: 'bg-amber-100 text-amber-600' },
    { label: 'Docs', value: camels.reduce((acc, c) => acc + c.documents.length, 0), icon: ICONS.File, color: 'bg-blue-100 text-blue-600' },
  ];

  return (
    <div className="space-y-6 lg:space-y-10 animate-in fade-in duration-500">
      <div className="bg-[#3E2723] rounded-[2.5rem] p-8 lg:p-12 shadow-2xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-3xl lg:text-5xl font-black text-white leading-tight">Marhaba, {user.name.split(' ')[0]}!</h1>
            <p className="text-white/60 mt-3 text-lg font-medium">Manage your digital herd registry and track lineages.</p>
            
            <form onSubmit={handleChipSearch} className="mt-10 relative flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1 group">
                <input 
                  type="text" 
                  value={chipInput}
                  onChange={(e) => setChipInput(e.target.value)}
                  placeholder="Scan or Enter Chip / Serial No." 
                  className="w-full bg-white/10 border-2 border-white/10 focus:border-[#D2691E] px-14 py-5 rounded-[1.5rem] text-white font-black text-lg outline-none placeholder:text-white/30 transition-all backdrop-blur-md group-hover:bg-white/15"
                />
                <ICONS.Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-[#D2691E]" />
              </div>
              <button 
                type="submit"
                className="px-10 py-5 bg-[#D2691E] text-white rounded-[1.5rem] font-black uppercase tracking-widest text-sm hover:bg-white hover:text-[#3E2723] transition-all active:scale-95 shadow-lg shadow-[#D2691E]/20"
              >
                Lookup Record
              </button>
            </form>
          </div>
        </div>
        <ICONS.Camel className="absolute -bottom-10 -right-10 w-64 h-64 text-white/5 pointer-events-none rotate-12" />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex flex-col items-center text-center space-y-3 group hover:border-[#D2691E]/30 transition-all">
            <div className={`p-4 rounded-2xl ${stat.color} shrink-0 shadow-sm group-hover:scale-110 transition-transform`}>
              <stat.icon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{stat.label}</p>
              <p className="text-2xl font-black text-[#3E2723] mt-1">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
               <h3 className="text-xl font-black text-[#3E2723]">Recent Records</h3>
               <span className="px-3 py-1 bg-gray-100 text-gray-400 rounded-full text-[10px] font-black uppercase tracking-widest">Herd Index</span>
            </div>
            <button className="text-xs font-black text-[#D2691E] hover:underline uppercase tracking-widest">View Directory &rarr;</button>
          </div>
          
          {camels.length === 0 ? (
            <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-16 text-center flex flex-col items-center">
              <div className="w-20 h-20 bg-gray-50 rounded-3xl flex items-center justify-center text-gray-200 mb-6">
                <ICONS.Camel className="w-10 h-10" />
              </div>
              <p className="text-gray-400 font-bold text-sm uppercase tracking-[0.2em]">No animals recorded</p>
              <button 
                onClick={onAddCamel}
                className="mt-6 text-sm font-black text-[#D2691E] hover:underline"
              >
                + Register First Camel
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {camels.slice(0, 4).map(camel => (
                <div 
                  key={camel.id} 
                  onClick={() => onViewCamel(camel)}
                  className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center gap-5 hover:border-[#D2691E]/30 cursor-pointer transition-all active:scale-[0.98]"
                >
                  <div className="relative w-16 h-16 rounded-2xl bg-[#F4E4BC] flex items-center justify-center text-[#D2691E] shrink-0 shadow-inner overflow-hidden border-2 border-white">
                    {camel.imageUrl ? (
                      <img src={camel.imageUrl} alt={camel.name} className="w-full h-full object-cover" />
                    ) : (
                      <ICONS.Camel className="w-8 h-8" />
                    )}
                    {camel.verificationStatus === VerificationStatus.VERIFIED && (
                      <div className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-0.5 border-2 border-white shadow-sm">
                         <ICONS.Check className="w-2.5 h-2.5 text-white" strokeWidth={5} />
                      </div>
                    )}
                  </div>
                  <div className="overflow-hidden flex-1">
                    <p className="font-black text-[#3E2723] text-lg truncate leading-tight">{camel.name}</p>
                    <p className="text-xs text-[#D2691E] font-black uppercase tracking-widest mt-1 truncate">{camel.breed}</p>
                    <p className="text-[10px] text-gray-400 font-bold mt-2 uppercase tracking-tighter">Chip: {camel.chipNumber}</p>
                  </div>
                  <div className="shrink-0 flex flex-col items-end gap-3">
                    <StatusBadge status={camel.verificationStatus} />
                    <div className="p-1.5 bg-gray-50 rounded-lg text-gray-300">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" /></svg>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="flex items-center gap-3 px-2">
             <h3 className="text-xl font-black text-[#3E2723]">Quick Actions</h3>
          </div>
          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-sm p-8 space-y-6">
             <button 
                onClick={onAddCamel}
                className="w-full flex items-center gap-4 p-5 bg-[#D2691E]/5 hover:bg-[#D2691E]/10 rounded-2xl transition-all group"
             >
                <div className="w-12 h-12 bg-[#D2691E] text-white rounded-xl flex items-center justify-center shadow-lg shadow-[#D2691E]/20 group-hover:scale-110 transition-transform">
                   <ICONS.Plus className="w-6 h-6" />
                </div>
                <div className="text-left">
                   <p className="font-black text-[#3E2723] text-sm">Add New Camel</p>
                   <p className="text-[10px] text-[#D2691E] font-bold uppercase tracking-widest mt-0.5">Start Registration</p>
                </div>
             </button>

             <button 
                onClick={onNavigateToFamily}
                className="w-full flex items-center gap-4 p-5 bg-[#8A9A5B]/5 hover:bg-[#8A9A5B]/10 rounded-2xl transition-all group"
             >
                <div className="w-12 h-12 bg-[#8A9A5B] text-white rounded-xl flex items-center justify-center shadow-lg shadow-[#8A9A5B]/20 group-hover:scale-110 transition-transform">
                   <ICONS.Users className="w-6 h-6" />
                </div>
                <div className="text-left">
                   <p className="font-black text-[#3E2723] text-sm">Herd Family</p>
                   <p className="text-[10px] text-[#8A9A5B] font-bold uppercase tracking-widest mt-0.5">Invite Members</p>
                </div>
             </button>

             <div className="pt-6 border-t border-gray-50 mt-2">
                <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100 italic text-xs text-gray-500 text-center font-medium leading-relaxed">
                   "Pedigree records are the heart of desert biological heritage."
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
