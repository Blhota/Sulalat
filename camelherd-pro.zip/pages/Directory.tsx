
import React, { useState } from 'react';
import { Camel, VerificationStatus } from '../types';
import { ICONS, BREEDS } from '../constants';
import StatusBadge from '../components/StatusBadge';

interface DirectoryProps {
  camels: Camel[];
  onViewCamel: (camel: Camel) => void;
  onNavigateToFamily: () => void;
}

const Directory: React.FC<DirectoryProps> = ({ camels, onViewCamel, onNavigateToFamily }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [breedFilter, setBreedFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  if (camels.length === 0 && searchTerm === '' && breedFilter === 'All' && statusFilter === 'All') {
     return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 animate-in fade-in duration-500">
        <div className="w-24 h-24 bg-[#F4E4BC] rounded-[2rem] flex items-center justify-center text-[#D2691E] shadow-xl shadow-[#D2691E]/10">
          <ICONS.Camel className="w-12 h-12" />
        </div>
        <div className="max-w-md space-y-2">
          <h2 className="text-2xl font-black text-[#3E2723]">Your herd is empty</h2>
          <p className="text-gray-500 font-medium">Start adding your animals to build your digital heritage collection. If you are part of a family, make sure you've joined their herd.</p>
        </div>
        <button 
          onClick={onNavigateToFamily}
          className="px-8 py-4 bg-[#3E2723] text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-[#3E2723]/20"
        >
          Manage Family/Herd
        </button>
      </div>
    );
  }

  const filteredCamels = camels.filter(camel => {
    const matchesSearch = 
      camel.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      camel.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      camel.chipNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesBreed = breedFilter === 'All' || camel.breed === breedFilter;
    const matchesStatus = statusFilter === 'All' || camel.verificationStatus === statusFilter;
    
    return matchesSearch && matchesBreed && matchesStatus;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-10">
      <div className="bg-white p-4 lg:p-6 rounded-2xl lg:rounded-3xl border border-gray-100 shadow-sm flex flex-col gap-4">
        <div className="relative w-full">
           <ICONS.Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
           <input 
             type="text" 
             placeholder="Search herd..." 
             className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border-none rounded-xl outline-none focus:ring-2 focus:ring-[#D2691E] font-medium text-sm"
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
           />
        </div>
        <div className="grid grid-cols-2 gap-3">
           <select 
             className="w-full bg-gray-50 border-none px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold text-xs text-gray-600 appearance-none text-center uppercase tracking-wider"
             value={breedFilter}
             onChange={(e) => setBreedFilter(e.target.value)}
           >
             <option value="All">All Breeds</option>
             {BREEDS.map(b => <option key={b} value={b}>{b}</option>)}
           </select>
           <select 
             className="w-full bg-gray-50 border-none px-4 py-3 rounded-xl outline-none focus:ring-2 focus:ring-[#D2691E] font-bold text-xs text-gray-600 appearance-none text-center uppercase tracking-wider"
             value={statusFilter}
             onChange={(e) => setStatusFilter(e.target.value)}
           >
             <option value="All">All Status</option>
             <option value={VerificationStatus.VERIFIED}>Verified Only</option>
             <option value={VerificationStatus.PENDING}>Review Pending</option>
           </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        {filteredCamels.map(camel => (
          <div 
            key={camel.id} 
            onClick={() => onViewCamel(camel)}
            className="group bg-white rounded-2xl lg:rounded-3xl border border-gray-100 shadow-sm overflow-hidden active:scale-[0.98] transition-all duration-200 cursor-pointer"
          >
            <div className="relative h-40 lg:h-48 bg-[#F4E4BC] flex items-center justify-center text-[#D2691E] overflow-hidden">
               {camel.imageUrl ? (
                 <img src={camel.imageUrl} alt={camel.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
               ) : (
                 <ICONS.Camel className="w-20 h-20" />
               )}
               <div className="absolute top-3 right-3 scale-90 origin-top-right">
                  <StatusBadge status={camel.verificationStatus} />
               </div>
               {camel.verificationStatus === VerificationStatus.VERIFIED && (
                 <div className="absolute bottom-4 right-4 bg-blue-500 rounded-full p-1.5 border-4 border-white shadow-xl animate-in zoom-in duration-500">
                    <ICONS.Check className="w-4 h-4 text-white" strokeWidth={5} />
                 </div>
               )}
            </div>
            <div className="p-5 space-y-4">
               <div>
                  <h3 className="text-lg lg:text-xl font-bold text-[#3E2723] truncate">{camel.name}</h3>
                  <p className="text-[10px] font-black text-[#D2691E] uppercase tracking-widest mt-0.5">{camel.breed}</p>
               </div>
               <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-gray-400 font-bold uppercase text-[9px]">ID</p>
                    <p className="font-semibold text-[#3E2723] truncate">{camel.registrationNumber}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-400 font-bold uppercase text-[9px]">Chip</p>
                    <p className="font-semibold text-[#3E2723] truncate">{camel.chipNumber}</p>
                  </div>
               </div>
               <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
                  <div className="flex items-center gap-2 overflow-hidden">
                     <div className="w-6 h-6 rounded-full bg-[#8A9A5B] flex items-center justify-center text-[10px] text-white font-bold shrink-0">
                        {camel.ownerName.charAt(0)}
                     </div>
                     <span className="text-[10px] text-gray-500 font-bold uppercase truncate">{camel.ownerName}</span>
                  </div>
                  <div className="text-[#D2691E] font-black text-[10px] uppercase tracking-widest">
                    View Details &rarr;
                  </div>
               </div>
            </div>
          </div>
        ))}
      </div>

      {filteredCamels.length === 0 && searchTerm !== '' && (
        <div className="text-center py-20 bg-white rounded-2xl border border-gray-100">
           <ICONS.Camel className="w-16 h-16 text-gray-100 mx-auto" />
           <p className="mt-4 text-gray-400 font-bold uppercase text-xs tracking-widest">No matching animals found</p>
        </div>
      )}
    </div>
  );
};

export default Directory;
